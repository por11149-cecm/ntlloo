package com.porvenir.bff.validacion.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@Data
@Document(collection = "SEG_COMPROBACION")
public class CosmosDocument {
	
	@Id
	@Field(name = "COMPROBACION_ID")
	private Long Id;
	
	@Field(name = "IDENTIFICACION") //decriptedId
	private String identificacion;
	
	@Field(name = "TIPO_IDENTIFICACION") 
	private String identificacionType;
	
	@Field(name = "TOKEN")
	private String token;
	
	@Field(name = "USUARIO_CREACION") //decriptedId
	private String usuarioCreacion;
	
	@Field(name = "FECHA_CREACION")
	private String fechaCreacion;
	
	@Field(name = "USUARIO_ULTIMA_MODIFICACION")
	private String lastUpdateUser;
	
	@Field(name = "FECHA_ULTIMA_MODIFICACION")
	private String lastUpdateDate;
	
	public CosmosDocument(String identificacion, String identificacionType, String token, String usuarioCreacion,
			String fechaCreacion, String lastUpdateUser, String lastUpdateDate) {
		this.identificacion = identificacion;
		this.identificacionType = identificacionType;
		this.token = token;
		this.usuarioCreacion = usuarioCreacion;
		this.fechaCreacion = fechaCreacion;
		this.lastUpdateUser = lastUpdateUser;
		this.lastUpdateDate = lastUpdateDate;
	}

}