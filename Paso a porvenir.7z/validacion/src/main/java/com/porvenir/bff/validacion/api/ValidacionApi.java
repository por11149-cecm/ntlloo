package com.porvenir.bff.validacion.api;



import com.porvenir.bff.validacion.dto.MicrosoftToken;
import com.porvenir.bff.validacion.dto.ValidationJWT;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ValidacionApi {

	

	@FormUrlEncoded
	@POST("{tenantId}/oauth2/token")
	public Call<MicrosoftToken> responseMicrosoft(@Field("client_id") String client_id,
			@Field("grant_type") String grant_type,
			@Field("resource")String resource,
			@Field("client_secret")String client_secret,
			@Field("username")String username,
			@Field("password")String password,
			@Field("Host")String Host,
			@Field("scope")String scope,
			@Path("tenantId")String tenantId);
	
  
	@POST("porvenir-servicios-sds-app-movil/directorioactivo/iniciarSesion")
	public Call<Object> responseJWTValidation(@Header("headerRq") String headerRq,
													@Body ValidationJWT cuerpo);

	

	@POST("porvenir-servicios-sds-app-movil/directorioactivo/dispositivo")
	public Call<Void> responseJWTEnrolamiento(@Header("headerRq") String headerRq,
													@Body ValidationJWT cuerpo);

	
}
