package com.porvenir.bff.validacion.controller;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.eventgrid.producer.producer.Producer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import org.apache.commons.io.IOUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
// @ExtendWith(OutputCaptureExtension.class)
public class DemoInterceptor extends OncePerRequestFilter {
	
		
	
	@Value("${application.bus.urlEvent}")
	private String urlEvent; 
	@Value("${application.bus.keyEvent}")
	private String keyEvent; 
	
	
	
        @Autowired
        private ObjectMapper objectMapper;

        /**
         * Metodo encargado de generar trazabilidad sobre los request y response
         */
        @Override
        protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                        FilterChain filterChain) throws ServletException, IOException {

                ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request);

                ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);

                filterChain.doFilter(requestWrapper, responseWrapper);

                String requestUrl = requestWrapper.getRequestURL().toString();
                HttpHeaders requestHeaders = new HttpHeaders();
                Enumeration headerNames = requestWrapper.getHeaderNames();
                while (headerNames.hasMoreElements()) {
                        String headerName = (String) headerNames.nextElement();
                        requestHeaders.add(headerName, requestWrapper.getHeader(headerName));
                }
                HttpMethod httpMethod = HttpMethod.valueOf(requestWrapper.getMethod());
                Map<String, String[]> requestParams = requestWrapper.getParameterMap();

                String requestBody = IOUtils.toString(requestWrapper.getInputStream(), UTF_8);

                if (requestBody.isEmpty()){
                        requestBody = new String(requestWrapper.getContentAsByteArray());
                }

                JsonNode requestJson = objectMapper.readTree(requestBody);

                RequestEntity<JsonNode> requestEntity = new RequestEntity<>(requestJson, requestHeaders, httpMethod,
                                URI.create(requestUrl));

                HttpStatus responseStatus = HttpStatus.valueOf(responseWrapper.getStatusCode());
                HttpHeaders responseHeaders = new HttpHeaders();
                for (String headerName : responseWrapper.getHeaderNames()) {
                        responseHeaders.add(headerName, responseWrapper.getHeader(headerName));
                }
                String responseBody = IOUtils.toString(responseWrapper.getContentInputStream(), UTF_8);
                Gson gson=new Gson();
                JsonNode responseJson = objectMapper.readTree(gson.toJson(responseBody));
                ResponseEntity<JsonNode> responseEntity = new ResponseEntity<>(responseJson, responseHeaders,
                                responseStatus);

                String ipAdress = getRemoteAddr(request);
                sendProducer(requestEntity, responseEntity);

                responseWrapper.copyBodyToResponse();

        }

        private String validarStringList(List<String> valor) {
                return valor == null || valor.isEmpty() ? "" : valor.toString();
        }

        private String validarString(String valor) {
                return valor == null || valor.isEmpty() ? "" : valor;
        }

        private void sendProducer(RequestEntity<JsonNode> request, ResponseEntity<JsonNode> response) {

                Producer producer = new Producer();
                
                
                String code = response.getStatusCode()+"";
                String data = "LOG REGULAR";
                String action = validarString(request.getUrl().toString());
                String user = validarStringList(request.getHeaders().get("idusuario"));
                String ip = validarStringList(request.getHeaders().get("X-FORWARDED-FOR"));
                String host = validarStringList(request.getHeaders().get("Host"));
                String dateRequest = validarStringList(request.getHeaders().get("fecha"));
                DateTime date = DateTime.now().toDateTime(DateTimeZone.UTC).minusHours(5);
                
                String dateResponse = date.toString();
                String type = "";
                String requestStr = validarString(request.getBody() == null ? "" : "{ \"RequestDate\": " + dateRequest + "}" + request.getBody().toString());
                String responseStr = validarString("{ \"ResponseDate\": " + dateResponse + "}" + response.getBody().toString());
               
                
                if(responseStr.length() >= 1000000) {
                	
                	responseStr = responseStr.substring(0, 1000000);
                	
                }
                
                
                String dataProcessing = "N/A not yet";
                String table = "";
                String service = validarStringList(request.getHeaders().get("canal"));
                String browser = validarStringList(request.getHeaders().get("user-agent"));
        		BufferedWriter bw = null;
        		Scanner myReader = null;

                
                try {
                        File myObj = new File("cache.txt");
                        myReader = new Scanner(myObj);
                        while (myReader.hasNextLine()) {
                                String datos = myReader.nextLine();
                                table = table + datos;
                        }
                        
                        //Borramos cache

                        bw = new BufferedWriter(new FileWriter("cache.txt"));
                        bw.write("");

                } catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                } catch (Exception ex){
                        System.out.println("An error occurred.");
                        ex.printStackTrace();
                }
                //OBJETO A ENVIAR
                System.out.println("CODIGO "+ code);
                System.out.println("DATA "+ data);
                System.out.println("ACTION "+ action);
                System.out.println("USER "+ user);
                System.out.println("IP "+ ip);
                System.out.println("HOST "+host);
                System.out.println("DATE "+dateRequest+" "+date);
                System.out.println("TYPE "+ type);
                System.out.println("REQUEST "+requestStr);
                System.out.println("RESPONSE "+responseStr);
                System.out.println("DATA-PROCESING "+dataProcessing);
                System.out.println("TABLE "+table);
                System.out.println("SERVICE "+service);
                System.out.println("BROWSER "+browser);
                
                
                
                 try {
                 producer.sendEvent(
                 code, //c�digo
                 data,//descripcion
                 action,//acci�n
                 user,//usuario
                 ip,//ip
                 host, //host
                 date,//fecha y hora
                 type,//tipo
                 requestStr,//request
                 responseStr,//response
                 dataProcessing,//cantidad de datos procesados
                 table,//tabla
                 service,//servicio
                 browser,//Navegador
                 keyEvent,// key eventgrid
                 urlEvent,
                 //url eventgrid
                 "mobile");// proyecto
                 } catch (URISyntaxException ex) {
                 System.out.println(ex);
                 }
                 
         		finally {
        			safeClose(bw, myReader);
        		}

        }

        private String getRemoteAddr(HttpServletRequest request) {
                String ipFromHeader = request.getHeader("X-FORWARDED-FOR");
                if (ipFromHeader != null && ipFromHeader.length() > 0) {
                        return ipFromHeader;
                }
                return request.getRemoteAddr();
        }
        
        
              
        
        
 		public void safeClose(BufferedWriter bw ,Scanner myReader) {
 			if (bw != null) {

 				try {
 					bw.close();
 				} catch (IOException e) {

 					e.printStackTrace();

 				}
 			}

 			if (myReader != null) {

 				try {
 					myReader.close();
 				} catch (Exception e) {

 					e.printStackTrace();

 				}
 			}
 			

 		 }
        
}