package com.porvenir.bff.validacion.errores;

import java.util.ArrayList;
import org.springframework.http.HttpStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class ExceptionDeSistema{

    // ejemplo NEG200
    private String codigo;

    // El usuario no existe
    private String descripcion;

    // algo que quieran agregar
    private ArrayList<ErrorDetalleDTO> descripcionAdicional;

    private HttpStatus httpStatus;

    public static class ExceptionDeSistemaBuilder {

        public ExceptionDeSistemaBuilder agregarDescripcion2(String detalleP) {

            if (descripcionAdicional == null) {
                this.descripcionAdicional = new ArrayList<ErrorDetalleDTO>();
            }
            ErrorDetalleDTO detalle = new ErrorDetalleDTO();
            detalle.setDetalle(detalleP);
            this.descripcionAdicional.add(detalle);
            return this;
        }

    }

}
