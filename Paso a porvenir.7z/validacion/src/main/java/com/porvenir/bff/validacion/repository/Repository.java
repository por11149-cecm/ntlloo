package com.porvenir.bff.validacion.repository;


import java.util.Optional;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.porvenir.bff.validacion.model.Consulta;

@org.springframework.stereotype.Repository
public interface Repository extends MongoRepository<Consulta, Integer>{
	public Optional<Consulta> findByIDENTIFICACION(String idUsuario);
	public Optional<Consulta> deleteByIDENTIFICACION(String idUsuario);
	public Optional<Consulta> findByTOKEN(String token);
	
	
	@Query("{$and : [{IDENTIFICACION: ?0}, {TOKEN : ?1}]}")
	public Optional<Consulta> findByIDENTIFICACIONAndTOKEN(String idUsuario, String Token); 

}
