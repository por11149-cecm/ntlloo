package com.porvenir.bff.validacion.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.porvenir.bff.validacion.service.ValidacionService;



@RestController

public class ValidacionController {
	
	@Autowired
	ValidacionService servicio;


	
	@PostMapping(value = "/validar/**")
	public ResponseEntity<Object> autorizar(RequestEntity<String> request) throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, CertificateException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {

		return servicio.autorizarApi(request);
	}

	
	
	@PostMapping(path = "/validar/bff/v1/seguridad/login", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> login(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {
		
		
		return servicio.login(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("passwordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha, idusuario);
	
	}

	@PostMapping(path = "/validar/bff/v1/seguridad/enrolamiento", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> enrolamiento(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {


		return servicio.enrolamiento(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("passwordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha);
	}


	@PostMapping("/validar/bff/v1/seguridad/consultarLlave")
	public String consultarLlave(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha) throws IOException {

		InputStream inputStream = getClass().getResourceAsStream("/public3.key");

		try {

			byte[] publicKeyBytes = inputStream.readAllBytes();
			String str = Base64.getEncoder().encodeToString(publicKeyBytes);

			return str;

		} catch (Exception e) {
			return null;
		}

		finally {

			safeClose(inputStream);

		}

	}	

	@PostMapping(path = "/validar/bff/v1/seguridad2/login", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> login2(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {
		
		
		return servicio.login(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("passwordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha, idusuario);
	
	}

	@PostMapping(path = "/validar/bff/v1/seguridad2/enrolamiento", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> enrolamiento2(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {


		return servicio.enrolamiento(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("passwordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha);
	}


	@PostMapping("/validar/bff/v1/seguridad2/consultarLlave")
	public String consultarLlave2() throws IOException {

		InputStream inputStream = getClass().getResourceAsStream("/public3.key");

		try {

			byte[] publicKeyBytes = inputStream.readAllBytes();
			String str = Base64.getEncoder().encodeToString(publicKeyBytes);

			return str;

		} catch (Exception e) {
			return null;
		}

		finally {

			safeClose(inputStream);

		}

	}	


	
	public static void safeClose(InputStream inputStream) {

		if (inputStream != null) {

			try {
				inputStream.close();
			} catch (IOException e) {

				e.printStackTrace();

			}
		}

	}

	
}
