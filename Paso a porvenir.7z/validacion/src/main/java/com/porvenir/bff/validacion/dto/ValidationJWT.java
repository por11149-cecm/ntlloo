package com.porvenir.bff.validacion.dto;

import lombok.Data;

@Data
public class ValidationJWT {

	private Dispositivo dispositivo = new Dispositivo();
	private String jwt;
}
