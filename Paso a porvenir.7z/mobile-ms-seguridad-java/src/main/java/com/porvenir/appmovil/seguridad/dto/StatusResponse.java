package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;


@Data
public class StatusResponse {

  private String logref;
  private String message;
  
}
