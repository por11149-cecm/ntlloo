package com.porvenir.appmovil.seguridad.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.porvenir.appmovil.seguridad.model.Componente;


/**
* Clase encargada de representar las consultas relativas al Componente
* @since 1.0
*/
@Repository
public interface ComponenteRepository extends CrudRepository<Componente, Integer> {

	
	

}
