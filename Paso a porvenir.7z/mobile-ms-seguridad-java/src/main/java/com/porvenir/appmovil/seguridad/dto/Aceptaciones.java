package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class Aceptaciones {

	private Integer idDocumento;
	private String aplicacion;
	private String ip;
	private String tipoIdAfil;
	private Integer numeroIdAfil;
	private String transaccion;
	private String conceptoAceptacion;
	private String respuesta;
	private String usuarioCreacion;
	private String nombrePortafolio;
	private Integer numeroCuentaPI;
	
}
