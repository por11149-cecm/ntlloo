package com.porvenir.appmovil.seguridad.api;


import com.porvenir.appmovil.seguridad.dto.AceptacionDoc;
import com.porvenir.appmovil.seguridad.dto.BodyDatosAfiliado;
import com.porvenir.appmovil.seguridad.dto.GuardarTerminosYCondicionesRequest;
import com.porvenir.appmovil.seguridad.dto.GuardarTerminosYCondicionesResponse;
import com.porvenir.appmovil.seguridad.dto.TerminosYCondiciones;
import com.porvenir.appmovil.seguridad.dto.ValidationJWT;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface SeguridadApi {

	

	
	@POST("porvenir-servicios-sds-app-movil/directorioactivo/cambioClaveOlvido")
	public Call<Void> responseJWTCambioClaveOlvido(@Header("headerRq") String headerRq,
                          @Body ValidationJWT cuerpo);
	
	@POST("porvenir-servicios-sds-app-movil/directorioactivo/cambioClaveVoluntario")
	public Call<Void> responseJWTCambioClaveVoluntario(@Header("headerRq") String headerRq,
                          @Body ValidationJWT cuerpo);
  
	
	@GET("terminosYCondiciones/canales/v1/consultarDocumento")
	public Call<TerminosYCondiciones> responseTerminosYCondiciones(@Header("serviceTransaction") String serviceTransaction,
																	@Header("headerRQ") String headerRQ,
																	@Header("serviceID") String serviceID,
																	@Header("userID") String userID,
																	@Query("tipoDocumento") String tipoDocumento,
																	@Query("codigoReferencia") String codigoReferencia,
																	@Query("funcionalidad") String funcionalidad,
																	@Query("producto") String producto);
	
	@POST("wsGestionDocumentosWeb/canales/v1/GestionDocumentos/guardarAceptacionDocumento")
	public Call<GuardarTerminosYCondicionesResponse> responseGuardarTerminosYCondiciones(@Header("serviceTransaction") String serviceTransaction,
                                  @Header("headerRQ") String headerRQ,
                                  @Header("serviceID") String serviceID,
                                  @Body GuardarTerminosYCondicionesRequest entrada);
	
	@GET("wsGestionDocumentosWeb/canales/v1/GestionDocumentos/consultarUltimoDocAfiliado")
	public Call<AceptacionDoc> consultarUltimoDoc(
			@Header("serviceTransaction") String serviceTransaction,
			@Header("headerRq") String headerRq,
			@Header("serviceID") String serviceID,
			@Query("tipoDocumento") String tipoDocumento,
			@Query("producto") String producto,
			@Query("nombreReferencia") String nombreReferencia,
			@Query("codigoReferencia") String codigoReferencia,
			@Query("funcionalidad") String funcionalidad,
			@Query("tipoIdAfil") String tipoIdAfil,
			@Query("numeroIdAfil") String numeroIdAfil);
	
	
	@GET("wsConsultarDatosAfiliadoWeb/AAF02S01V01/v1/ConsultarDatosAfiliado")
	public Call<BodyDatosAfiliado> datosAfiliado(
			@Header("headerRq") String headerRq,
			@Header("serviceID") String serviceID,
			@Header("serviceTransaction") String serviceTransaction,
			@Header("userId") String userId,
			@Query("tipoDocumento") String tipoDocumento,
			@Query("numeroDocumento")String numeroDocumento);  
	
}
