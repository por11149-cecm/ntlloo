package com.porvenir.appmovil.seguridad.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.spec.InvalidKeySpecException;
import java.text.ParseException;
import java.util.Base64;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.porvenir.appmovil.seguridad.dto.GuardarTerminosYCondicionesRequest;
import com.porvenir.appmovil.seguridad.dto.PermisosDTO;
import com.porvenir.appmovil.seguridad.dto.ReqContenido;
import com.porvenir.appmovil.seguridad.service.SeguridadService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("${application.mobile.api.path}")
@CrossOrigin(origins = "*")
@Api(tags = "ms-seguridad")
public class SeguridadController {

	@Autowired
	SeguridadService seguridadService;

	@Value("${application.twilio.ACCOUNT_SID}")
	private String ACCOUNT_SID;

	@Value("${application.twilio.AUTH_TOKEN}")
	private String AUTH_TOKEN;

	@Value("${application.twilio.SERVICE_ID}")
	private String SERVICE_ID;

	@Value("${application.bus.serviceTransactionTYC}")
	private String serviceTransactionTYC;

	@Value("${application.bus.serviceIDTYC}")
	private String serviceIDTYC;

	@Value("${application.bus.headerRQ}")
	private String headerRQ;

	@Value("${application.bus.userID}")
	private String userID;

	@Value("${application.bus.serviceTransactionTYCGuardar}")
	private String serviceTransactionTYCGuardar;

	@Value("${application.bus.serviceIDTYCGuardar}")
	private String serviceIDTYCGuardar;

	@Value("${application.bus.headerRQGuardar}")
	private String headerRQGuardar;

	@Value("${application.bus.serviceTransactionConsultarUltimoDoc}")
	private String serviceTransactionConsultarUltimoDoc;

	@Value("${application.bus.serviceIdConsultarUltimoDoc}")
	private String serviceIdConsultarUltimoDoc;

	@Value("${application.bus.headerRqConsultarUltimoDoc}")
	private String headerRqConsultarUltimoDoc;

	/**
	 * Metodo encargado de consultar los permisos de la aplicacion
	 * 
	 * @param request
	 * @return PermisosDTO
	 * @throws ParseException
	 */

	@PostMapping("/consultarPermisos")
	@ApiResponses({ @ApiResponse(code = 200, message = "Se ejecuto satisfactoriamente."),
			@ApiResponse(code = 400, message = "El cliente envio datos incorrectos.", response = Exception.class),
			@ApiResponse(code = 500, message = "Error inesperado.", response = Exception.class) })
	public PermisosDTO consultarPermisos() {

		PermisosDTO permisos = new PermisosDTO();
		permisos.setListaPermisos(seguridadService.consultarPermisos());
		return permisos;

	}

	@PostMapping(path = "/cambioClaveOlvido", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> cambioClaveOlvido(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {

		return seguridadService.cambioClaveOlvido(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("newPasswordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha);
	}

	@PostMapping(path = "/cambioClaveVoluntario", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> cambioClaveVoluntario(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {

		return seguridadService.cambioClaveVoluntario(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("oldPasswordApp"),
				requestContent.get("newPasswordApp"), requestContent.get("nombreDispositivo"),
				requestContent.get("serialDispositivo"), ipaddr, fecha);
	}

	@PostMapping("/consultarLlave")
	public String consultarLlave() throws IOException {

		InputStream inputStream = getClass().getResourceAsStream("/public3.key");

		try {

			byte[] publicKeyBytes = inputStream.readAllBytes();
			String str = Base64.getEncoder().encodeToString(publicKeyBytes);

			return str;

		} catch (Exception e) {
			return null;
		}

		finally {

			safeClose(inputStream);

		}

	}

	@PostMapping(path = "/enviarOTP", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String enviarMensaje(@RequestBody Map<String, String> entrada) {

		return seguridadService.enviarOTP(entrada.get("tipoIdentificacion"), entrada.get("numeroIdentificacion"));

	}

	@PostMapping(path = "/verificarOTP", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String verificarMensaje(@RequestBody Map<String, String> entrada) {

		return seguridadService.verificarOTP(entrada.get("tipoIdentificacion"), entrada.get("numeroIdentificacion"),
				entrada.get("verification"));

	}

	@PostMapping(path = "/terminosYCondiciones", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> terminos(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr", required = false) String ipaddr,
			@RequestHeader(value = "idrequest") String idrequest, @RequestHeader(value = "idusuario") String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestHeader(value = "authorization") String authorization,
			@RequestBody Map<String, String> entrada)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {
		return seguridadService.terminos(serviceTransactionTYC, serviceIDTYC, headerRQ, userID,
				entrada.get("tipoDocumento"), entrada.get("codigoReferencia"), entrada.get("funcionalidad"),
				entrada.get("producto"));
	}

	@PostMapping(path = "/guardarTerminosYCondiciones", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> guardarTerminos(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr", required = false) String ipaddr,
			@RequestHeader(value = "idrequest") String idrequest, @RequestHeader(value = "idusuario") String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestHeader(value = "authorization") String authorization,
			@RequestBody GuardarTerminosYCondicionesRequest entrada)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {

		return seguridadService.guardarTerminos(serviceTransactionTYCGuardar, serviceIDTYCGuardar, headerRQGuardar,
				entrada);

	}

	@PostMapping(path = "/consultarUltimoDocAfiliado", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> consultarUltimoDocAfiliado(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr", required = false) String ipaddr,
			@RequestHeader(value = "idrequest") String idrequest, @RequestHeader(value = "idusuario") String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestHeader(value = "authorization") String authorization,
			@RequestBody ReqContenido contenido) throws KeyManagementException, NoSuchAlgorithmException {

		return seguridadService.consultarUltimoDoc(serviceTransactionConsultarUltimoDoc, headerRqConsultarUltimoDoc,
				serviceIdConsultarUltimoDoc, contenido.getCodigoReferencia(), contenido.getFuncionalidad(),
				contenido.getNombreReferencia(), contenido.getNumeroIdAfil(), contenido.getProducto(),
				contenido.getTipoDocumento(), contenido.getTipoIdAfil());

	}

	public static void safeClose(InputStream inputStream) {

		if (inputStream != null) {

			try {
				inputStream.close();
			} catch (IOException e) {

				e.printStackTrace();

			}
		}

	}

}
