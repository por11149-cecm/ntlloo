package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class AceptacionDoc {
	
    private AceptacionDocContent aceptacionDoc;
    private Documento documento;
    private Status status;
  

}
