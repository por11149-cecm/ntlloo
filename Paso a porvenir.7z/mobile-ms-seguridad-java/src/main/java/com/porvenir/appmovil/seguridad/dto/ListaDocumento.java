
package com.porvenir.appmovil.seguridad.dto;


import lombok.Data;

@Data
public class ListaDocumento {

    private String codigoReferencia;
    private String contenidoDocumento;
    private String fechaCreacion;
    private String funcionalidad;
    private Integer idDocumento;
    private String nombreDocumento;
    private String producto;
    private String tipoDocumento;
    private String usuarioCreacion;
    private Integer version;
  
}
