package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class Request {
	
	private String client_id;
	private String grant_type;
	private String resource;
	private String client_secret;
	private String username;
	private String password;
	private String host;
	private String scope;

}
