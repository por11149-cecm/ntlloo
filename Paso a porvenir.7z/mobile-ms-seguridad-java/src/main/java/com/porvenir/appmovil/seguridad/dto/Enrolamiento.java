package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;
@Data
public class Enrolamiento {
  
  
    private StatusResponse status = new StatusResponse();
    private Token token = new Token();
  

}
