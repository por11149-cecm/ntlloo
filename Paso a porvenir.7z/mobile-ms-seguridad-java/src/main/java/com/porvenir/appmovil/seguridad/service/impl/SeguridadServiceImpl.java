package com.porvenir.appmovil.seguridad.service.impl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyManagementException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.porvenir.appmovil.seguridad.api.SeguridadApi;
import com.porvenir.appmovil.seguridad.config.SeguridadClient;
import com.porvenir.appmovil.seguridad.dto.AceptacionDoc;
import com.porvenir.appmovil.seguridad.dto.BodyDatosAfiliado;
import com.porvenir.appmovil.seguridad.dto.GuardarTerminosYCondicionesRequest;
import com.porvenir.appmovil.seguridad.dto.GuardarTerminosYCondicionesResponse;
import com.porvenir.appmovil.seguridad.dto.HeaderRqJWT;
import com.porvenir.appmovil.seguridad.dto.ResponseValidationJWT;
import com.porvenir.appmovil.seguridad.dto.TerminosYCondiciones;
import com.porvenir.appmovil.seguridad.dto.ValidationJWT;
import com.porvenir.appmovil.seguridad.errores.ExceptionDeSistema;
import com.porvenir.appmovil.seguridad.model.Componente;
import com.porvenir.appmovil.seguridad.repository.ComponenteRepository;
import com.porvenir.appmovil.seguridad.service.SeguridadService;
import com.porvenir.appmovil.seguridad.utils.ConstantesSeguridad;
import com.twilio.Twilio;
import com.twilio.rest.verify.v2.service.Verification;
import com.twilio.rest.verify.v2.service.VerificationCheck;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;

@Service

public class SeguridadServiceImpl implements SeguridadService {

	@Value("${application.twilio.ACCOUNT_SID}")
	private String ACCOUNT_SID;

	@Value("${application.twilio.AUTH_TOKEN}")
	private String AUTH_TOKEN;

	@Value("${application.twilio.SERVICE_ID}")
	private String SERVICE_ID;

	@Value("${application.oauth.client_id}")
	private String client_id;

	@Value("${application.oauth.grant_type}")
	private String grant_type;

	@Value("${application.oauth.resource}")
	private String resource;

	@Value("${application.oauth.client_secret}")
	private String client_secret;

	@Value("${application.oauth.username}")
	private String username;

	@Value("${application.oauth.password}")
	private String password;

	@Value("${application.oauth.host}")
	private String host;

	@Value("${application.oauth.scope}")
	private String scope;

	@Value("${application.oauth.tenantId}")
	private String tenantId;

	@Value("${application.rsa}")
	private String RSA;

	@Value("${application.bus.headerRqDatosAfiliado}")
	private String headerRqDatosAfiliado;

	@Value("${application.bus.serviceIDDatosAfiliado}")
	private String serviceIDDatosAfiliado;

	@Value("${application.bus.serviceTransactionDatosAfiliado}")
	private String serviceTransactionDatosAfiliado;

	@Value("${application.bus.userIdDatosAfiliado}")
	private String userIdDatosAfiliado;

	@Autowired
	ComponenteRepository repositorioDeComponentes;

	public ArrayList<Componente> consultarPermisos() {
		return (ArrayList<Componente>) repositorioDeComponentes.findAll();
	}

	@Override
	public ResponseEntity<Object> cambioClaveOlvido(String identificacionApp, String tipoIdentificacionApp,
			String newPasswordApp, String nombreDispositivo, String serialDispositivo, String ipaddr, String fecha)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {

		InputStream inputStream2 = getClass().getResourceAsStream("/private_key_Sds.der");

		try {

			byte[] keyBytesPorvenir = inputStream2.readAllBytes();

			PKCS8EncodedKeySpec specPorvenir = new PKCS8EncodedKeySpec(keyBytesPorvenir);
			KeyFactory kfPorvenir = KeyFactory.getInstance(RSA);
			PrivateKey privateKeyPorvenir = kfPorvenir.generatePrivate(specPorvenir);

			if (!newPasswordApp.isEmpty() && !identificacionApp.isEmpty() && !tipoIdentificacionApp.isEmpty()) {

				// Se decodifica en base 64 para obtener los bytes del hash

				String decryptedPas = desencriptar(newPasswordApp);
				String decryptedIdentificacion = desencriptar(identificacionApp);
				String decryptedTipoIdentificacion = desencriptar(tipoIdentificacionApp);

				String oldPass = "";

				String jwt = crearTokenPrivado(decryptedPas, oldPass, decryptedIdentificacion,
						decryptedTipoIdentificacion, privateKeyPorvenir);

				ResponseEntity<Object> obj = validarCambioClaveOlvido(jwt, ipaddr, fecha, nombreDispositivo,
						serialDispositivo, decryptedIdentificacion);

				if (obj.getBody() instanceof ResponseValidationJWT) {

					ResponseValidationJWT responseValidationJWT = (ResponseValidationJWT) obj.getBody();

					if (responseValidationJWT.getStatus() == 200 || responseValidationJWT.getStatus() == 202) {

						return ResponseEntity.ok().body(responseValidationJWT);

					} else {

						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
								.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
										.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION).build());

					}
				} else {

					return obj;
				}

			} else {

				return ResponseEntity.badRequest()
						.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.NEG0032)
								.descripcion(ConstantesSeguridad.NEG0032_DESCRIPTION).httpStatus(HttpStatus.BAD_REQUEST)
								.build());

			}

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
							.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION)
							.agregarDescripcion2("Error: " + e + " 1").build());

		}

		finally {
			safeClose(inputStream2);
		}

	}

	@Override
	public ResponseEntity<Object> cambioClaveVoluntario(String identificacionApp, String tipoIdentificacionApp,
			String oldPasswordApp, String newPasswordApp, String nombreDispositivo, String serialDispositivo,
			String ipaddr, String fecha) throws NoSuchAlgorithmException, FileNotFoundException, IOException,
			NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException,
			InvalidKeySpecException, KeyManagementException, NoSuchProviderException {

		InputStream inputStream2 = getClass().getResourceAsStream("/private_key_Sds.der");

		try {

			byte[] keyBytesPorvenir = inputStream2.readAllBytes();

			PKCS8EncodedKeySpec specPorvenir = new PKCS8EncodedKeySpec(keyBytesPorvenir);
			KeyFactory kfPorvenir = KeyFactory.getInstance(RSA);
			PrivateKey privateKeyPorvenir = kfPorvenir.generatePrivate(specPorvenir);

			if (!oldPasswordApp.isEmpty() && !newPasswordApp.isEmpty() && !identificacionApp.isEmpty()
					&& !tipoIdentificacionApp.isEmpty()) {

				// Se decodifica en base 64 para obtener los bytes del hash
				String decryptedOldPas = desencriptar(oldPasswordApp);
				String decryptedNewPas = desencriptar(newPasswordApp);
				String decryptedIdentificacion = desencriptar(identificacionApp);
				String decryptedTipoIdentificacion = desencriptar(tipoIdentificacionApp);

				String jwt = crearTokenPrivado(decryptedNewPas, decryptedOldPas, decryptedIdentificacion,
						decryptedTipoIdentificacion, privateKeyPorvenir);

				ResponseEntity<Object> obj = validarCambioClaveVoluntario(jwt, ipaddr, fecha, nombreDispositivo,
						serialDispositivo, decryptedIdentificacion);

				if (obj.getBody() instanceof ResponseValidationJWT) {

					ResponseValidationJWT responseValidationJWT = (ResponseValidationJWT) obj.getBody();

					if (responseValidationJWT.getStatus() == 200 || responseValidationJWT.getStatus() == 202) {

						return ResponseEntity.ok().body(responseValidationJWT);

					} else if (responseValidationJWT.getStatus() == 409) {

						String arregloDesc = responseValidationJWT.getDesc();
						String rep1 = arregloDesc.replace("[", "");
						String rep2 = rep1.replace("]", "");
						String rep3 = rep2.replace("{", "");
						String rep4 = rep3.replace("}", "");
						String rep5 = rep4.replace("\"", "");
						String rep6 = rep5.replace("\\", "");

						System.out.println("prueba2: " + rep6);

						String[] conceptos = rep6.split(",");
						String[] individuales = conceptos[0].split(":");
						String[] individuales2 = conceptos[1].split(":");

						String log = individuales[1];
						String desc = individuales2[1];

						responseValidationJWT.setLogRef(log);
						responseValidationJWT.setDesc(desc);

						return ResponseEntity.status(HttpStatus.CONFLICT).body(responseValidationJWT);

					} else {

						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
								.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
										.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION).build());

					}
				} else {

					return obj;
				}

			} else {

				return ResponseEntity.badRequest()
						.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.NEG0032)
								.descripcion(ConstantesSeguridad.NEG0032_DESCRIPTION).httpStatus(HttpStatus.BAD_REQUEST)
								.build());

			}

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
							.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION)
							.agregarDescripcion2("Error: " + e + " 1").build());

		}

		finally {
			safeClose(inputStream2);
		}

	}

	@Override
	public ResponseEntity<Object> terminos(String serviceTransaction, String serviceID, String headerRQ, String userID,
			String tipoDocumento, String codigoReferencia, String funcionalidad, String producto)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {

		try {

			Retrofit retrofitInstance = SeguridadClient.retrofitInstance3();
			SeguridadApi ejemploApi = retrofitInstance.create(SeguridadApi.class);

			Call<TerminosYCondiciones> token = ejemploApi.responseTerminosYCondiciones(serviceTransaction, headerRQ,
					serviceID, userID, tipoDocumento, codigoReferencia, funcionalidad, producto);

			Response<TerminosYCondiciones> execute = token.execute();

			TerminosYCondiciones detalle = execute.body();

			if (detalle.getStatus().getStatusCode() != 200) {

				return ResponseEntity.badRequest().body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.NEG0032)
						.descripcion(
								ConstantesSeguridad.NEG0032_DESCRIPTION + " " + detalle.getStatus().getStatusDesc())
						.httpStatus(HttpStatus.BAD_REQUEST).build());

			}

			return ResponseEntity.ok().body(detalle);

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
							.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION).agregarDescripcion2("Error: " + e)
							.build());

		}

	}

	@Override
	public ResponseEntity<Object> consultarUltimoDoc(String serviceTransaction, String headerRQ, String serviceID,
			String codigoReferencia, String funcionalidad, String nombreReferencia, String numeroIdAfil,
			String producto, String tipoDocumento, String tipoIdAfil)
			throws KeyManagementException, NoSuchAlgorithmException {

		Retrofit retrofitInstance = SeguridadClient.retrofitInstance3();
		SeguridadApi consultasApi = retrofitInstance.create(SeguridadApi.class);

		Call<AceptacionDoc> callAceptacion = consultasApi.consultarUltimoDoc(serviceTransaction, headerRQ, serviceID,
				tipoDocumento, producto, nombreReferencia, codigoReferencia, funcionalidad, tipoIdAfil, numeroIdAfil);

		try {

			Response<AceptacionDoc> responseAceptacion = callAceptacion.execute();

			AceptacionDoc aceptacionDoc = responseAceptacion.body();

			if (aceptacionDoc.getStatus().getStatusCode() != 200 && aceptacionDoc.getStatus().getStatusCode() != 0) {

				return ResponseEntity.badRequest()
						.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.NEG0032)
								.descripcion(ConstantesSeguridad.NEG0032_DESCRIPTION + " "
										+ aceptacionDoc.getStatus().getStatusDesc())
								.httpStatus(HttpStatus.BAD_REQUEST).build());

			}

			return ResponseEntity.ok().body(aceptacionDoc);

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
							.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION).agregarDescripcion2("Error: " + e)
							.build());
		}

	}

	@Override
	public ResponseEntity<Object> guardarTerminos(String serviceTransaction, String serviceID, String headerRQ,
			GuardarTerminosYCondicionesRequest entrada)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {
		try {

			// System.out.println(entrada);

			Retrofit retrofitInstance = SeguridadClient.retrofitInstance3();
			SeguridadApi ejemploApi = retrofitInstance.create(SeguridadApi.class);

			Call<GuardarTerminosYCondicionesResponse> call = ejemploApi
					.responseGuardarTerminosYCondiciones(serviceTransaction, headerRQ, serviceID, entrada);

			Response<GuardarTerminosYCondicionesResponse> execute = call.execute();

			GuardarTerminosYCondicionesResponse detalle = execute.body();

			if (detalle.getStatus().getStatusCode() != 200) {

				return ResponseEntity.badRequest().body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.NEG0032)
						.descripcion(
								ConstantesSeguridad.NEG0032_DESCRIPTION + " " + detalle.getStatus().getStatusDesc())
						.httpStatus(HttpStatus.BAD_REQUEST).build());

			}

			return ResponseEntity.ok().body(detalle);

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
							.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION).agregarDescripcion2("Error: " + e)
							.build());

		}
	}

	@Override
	public String enviarOTP(String tipoIdentificacion, String numeroIdentificacion) {

		try {

			Verification verification = null;
			String celularJhonatan = "3102124089";

			if (!tipoIdentificacion.isEmpty() && !numeroIdentificacion.isEmpty()) {

				String numeroIdentificacionDecrypted = desencriptar(numeroIdentificacion);

				String identificacion = numeroIdentificacionDecrypted.split("\\+")[0];

				String celular = obtenerCelularAfiliado(headerRqDatosAfiliado, serviceIDDatosAfiliado,
						serviceTransactionDatosAfiliado, userIdDatosAfiliado, tipoIdentificacion, identificacion);

				System.out.println("celular afiliado " + celular);

				Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

				verification = Verification.creator(SERVICE_ID, "+57" + celularJhonatan, "sms").create();

			}

			if (!verification.getStatus().equalsIgnoreCase("pending")) {

				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body("Error: " + verification.getStatus()).toString();

			}
			return "Estado operacion: " + verification.getStatus();

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage()).toString();

		}

	}

	@Override
	public String verificarOTP(String tipoIdentificacion, String numeroIdentificacion, String verification) {

		InputStream inputStream = getClass().getResourceAsStream("/private3.key");

		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

		try {

			VerificationCheck verificationCheck = null;
			String res = "";
			String celularJhonatan = "3102124089";

			byte[] keyBytes = inputStream.readAllBytes();

			PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
			KeyFactory kf = KeyFactory.getInstance(RSA);
			PrivateKey privateKey = kf.generatePrivate(spec);

			if (!tipoIdentificacion.isEmpty() || !numeroIdentificacion.isEmpty() || !verification.isEmpty()) {

				// Se decodifica en base 64 para obtener los bytes del hash
				byte[] decodedVer = Base64.getDecoder().decode(verification);
				Cipher decryptCipherVer = Cipher.getInstance(RSA);
				decryptCipherVer.init(Cipher.DECRYPT_MODE, privateKey);
				// Se desencripta el mensaje con la llave privada.

				byte[] decryptedVerBytes = decryptCipherVer.doFinal(decodedVer);
				String decryptedVer = new String(decryptedVerBytes, StandardCharsets.UTF_8);
				String numeroIdentificacionDecrypted = desencriptar(numeroIdentificacion);
				String identificacion = numeroIdentificacionDecrypted.split("\\+")[0];
				String celular = obtenerCelularAfiliado(headerRqDatosAfiliado, serviceIDDatosAfiliado,
						serviceTransactionDatosAfiliado, userIdDatosAfiliado, tipoIdentificacion, identificacion);

				String[] telefonoSplit = celular.split("");
				String[] codeSplit = decryptedVer.split("");

				verificationCheck = VerificationCheck.creator(SERVICE_ID, decryptedVer).setTo("+57" + celularJhonatan)
						.create();

				res = verificationCheck.getStatus() + codeSplit[0] + codeSplit[1] + telefonoSplit[0] + telefonoSplit[1]
						+ telefonoSplit[8] + telefonoSplit[9];

			}

			if (!verificationCheck.getStatus().equalsIgnoreCase("approved")) {

				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body("Error: " + verificationCheck.getStatus()).toString();

			}
			return "Estado operacion: " + toHexString(getSHA(res));

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage()).toString();
		}

		finally {
			safeClose(inputStream);
		}

	}

	public static String crearTokenPrivado(String decryptedNewPas, String decryptedOldPas,
			String decryptedIdentificacion, String decryptedTipoIdentificacion, PrivateKey privateKey)

	{

		Map<String, Object> claims = new HashMap<>();
		claims.put("identificacion", decryptedIdentificacion);
		claims.put("tipoIdentificacion", decryptedTipoIdentificacion);
		claims.put("password", decryptedNewPas);
		claims.put("oldPassword", decryptedOldPas);
		return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.RS512, privateKey).compact();
	}

	public ResponseEntity<Object> validarCambioClaveOlvido(String jwt, String ipaddr, String fecha,
			String nombreDispositivo, String serialDispositivo, String numeroIdentificacion)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {

		System.out.println("validador de ingreso SDS");
		LocalDateTime time = LocalDateTime.now();
		int numero = (int) (Math.random() * 100 + 1);
		String num = Integer.toString(numero);

		System.out.println("nombreDispositivo " + nombreDispositivo);
		System.out.println("serialDispositivo " + serialDispositivo);

		System.out.println("num id " + numeroIdentificacion);

		String[] numeroIdentificacionSplit = numeroIdentificacion.split("");

		String numeroString = time.toString();

		System.out.println("fecha " + numeroString);

		String numeroSinGuion = numeroString.replace("-", "");
		String numeroSinT = numeroSinGuion.replace("T", "");
		String numeroSinDosPuntos = numeroSinT.replace(":", "");
		String numeroSinPunto = numeroSinDosPuntos.replace(".", "");

		String numeroConY = numeroSinPunto.replace("", "Y");
		String[] numeroDividido = numeroConY.split("Y");

		System.out.println("fecha Y " + numeroConY);

		String rquid = numeroDividido[3] + numeroDividido[4] + numeroDividido[5] + numeroDividido[6] + numeroDividido[7]
				+ numeroDividido[8] + numeroDividido[9] + numeroDividido[10] + numeroDividido[11] + numeroDividido[12]
				+ numeroDividido[13] + numeroDividido[14] + numeroIdentificacionSplit[2] + numeroIdentificacionSplit[3]
				+ numeroIdentificacionSplit[4] + num + "1";

		HeaderRqJWT headerRq = new HeaderRqJWT();
		headerRq.setRqUID(rquid);
		headerRq.setChannelID("ZMA");
		headerRq.setClientID("APP");
		headerRq.setClientName("0");
		headerRq.setSucursalID("0");
		headerRq.setSucursalName("0");
		headerRq.setIpAddr(ipaddr);
		headerRq.setSessKey("0");
		headerRq.setClientDt(fecha);
		headerRq.setUserID("APP-V1");
		headerRq.setLoginID("0");
		headerRq.setRevCode("0");
		headerRq.setRevUID("0");
		headerRq.setRevAuthID("0");

		String serialDis = serialDispositivo.replace("-", "");

		ValidationJWT validation = new ValidationJWT();
		validation.getDispositivo().setNombre(nombreDispositivo);
		validation.getDispositivo().setSerial(serialDis);
		validation.setJwt(jwt);

		Gson gson = new Gson();
		String headerRqJSON = gson.toJson(headerRq);

		try {

			Retrofit retrofitInstance = SeguridadClient.retrofitInstance2();
			SeguridadApi ejemploApi = retrofitInstance.create(SeguridadApi.class);

			Call<Void> responseValidation = ejemploApi.responseJWTCambioClaveOlvido(headerRqJSON, validation);

			Response<Void> execute = responseValidation.execute();

			ResponseValidationJWT responseValidationJWT = new ResponseValidationJWT();
			int status = execute.code();

			if (status == 200 || status == 202) {

				responseValidationJWT.setStatus(status);

			} else {
				Object responseError = execute.errorBody().string();
				String strResponseError = (String) responseError;

				responseValidationJWT.setStatus(status);
				responseValidationJWT.setDesc(strResponseError);

			}

			return ResponseEntity.ok().body(responseValidationJWT);

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
							.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION)
							.agregarDescripcion2("Error: " + e.getMessage() + " 2").build());
		}
	}

	public ResponseEntity<Object> validarCambioClaveVoluntario(String jwt, String ipaddr, String fecha,
			String nombreDispositivo, String serialDispositivo, String numeroIdentificacion)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {

		System.out.println("validador de ingreso SDS");
		LocalDateTime time = LocalDateTime.now();
		int numero = (int) (Math.random() * 100 + 1);
		String num = Integer.toString(numero);

		System.out.println("nombreDispositivo " + nombreDispositivo);
		System.out.println("serialDispositivo " + serialDispositivo);

		System.out.println("num id " + numeroIdentificacion);

		String[] numeroIdentificacionSplit = numeroIdentificacion.split("");

		String numeroString = time.toString();

		System.out.println("fecha " + numeroString);

		String numeroSinGuion = numeroString.replace("-", "");
		String numeroSinT = numeroSinGuion.replace("T", "");
		String numeroSinDosPuntos = numeroSinT.replace(":", "");
		String numeroSinPunto = numeroSinDosPuntos.replace(".", "");

		String numeroConY = numeroSinPunto.replace("", "Y");
		String[] numeroDividido = numeroConY.split("Y");

		System.out.println("fecha Y " + numeroConY);

		String rquid = numeroDividido[3] + numeroDividido[4] + numeroDividido[5] + numeroDividido[6] + numeroDividido[7]
				+ numeroDividido[8] + numeroDividido[9] + numeroDividido[10] + numeroDividido[11] + numeroDividido[12]
				+ numeroDividido[13] + numeroDividido[14] + numeroIdentificacionSplit[2] + numeroIdentificacionSplit[3]
				+ numeroIdentificacionSplit[4] + num + "1";

		HeaderRqJWT headerRq = new HeaderRqJWT();
		headerRq.setRqUID(rquid);
		headerRq.setChannelID("ZMA");
		headerRq.setClientID("APP");
		headerRq.setClientName("0");
		headerRq.setSucursalID("0");
		headerRq.setSucursalName("0");
		headerRq.setIpAddr(ipaddr);
		headerRq.setSessKey("0");
		headerRq.setClientDt(fecha);
		headerRq.setUserID("APP-V1");
		headerRq.setLoginID("0");
		headerRq.setRevCode("0");
		headerRq.setRevUID("0");
		headerRq.setRevAuthID("0");

		String serialDis = serialDispositivo.replace("-", "");

		ValidationJWT validation = new ValidationJWT();
		validation.getDispositivo().setNombre(nombreDispositivo);
		validation.getDispositivo().setSerial(serialDis);
		validation.setJwt(jwt);

		Gson gson = new Gson();
		String headerRqJSON = gson.toJson(headerRq);

		try {

			Retrofit retrofitInstance = SeguridadClient.retrofitInstance2();
			SeguridadApi ejemploApi = retrofitInstance.create(SeguridadApi.class);

			Call<Void> responseValidation = ejemploApi.responseJWTCambioClaveVoluntario(headerRqJSON, validation);

			Response<Void> execute = responseValidation.execute();

			ResponseValidationJWT responseValidationJWT = new ResponseValidationJWT();
			int status = execute.code();

			if (status == 200 || status == 202) {

				responseValidationJWT.setStatus(status);

			} else {
				Object responseError = execute.errorBody().string();
				String strResponseError = (String) responseError;

				responseValidationJWT.setStatus(status);
				responseValidationJWT.setDesc(strResponseError);

			}

			return ResponseEntity.ok().body(responseValidationJWT);

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesSeguridad.TEC0006)
							.descripcion(ConstantesSeguridad.TEC0006_DESCRIPCION)
							.agregarDescripcion2("Error: " + e.getMessage() + " 2").build());
		}
	}

	public String desencriptar(String codigo) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException, IOException {

		InputStream inputStream = getClass().getResourceAsStream("/private3.key");

		try {

			byte[] keyBytes = inputStream.readAllBytes();

			PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
			KeyFactory kf = KeyFactory.getInstance(RSA);
			PrivateKey privateKey = kf.generatePrivate(spec);

			byte[] decoded = Base64.getDecoder().decode(codigo);
			Cipher decryptCipher = Cipher.getInstance(RSA);
			decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
			byte[] decryptedBytes = decryptCipher.doFinal(decoded);
			String decrypted = new String(decryptedBytes, StandardCharsets.UTF_8);

			return decrypted;

		} catch (Exception e) {

			return "Error en desencripcion de dato";
		}

		finally {
			safeClose(inputStream);
		}

	}

	public String obtenerCelularAfiliado(String headerRq, String serviceID, String serviceTransaction, String userId,
			String tipoDocumento, String numeroDocumento)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {

		try {

			Retrofit retrofitInstance = SeguridadClient.retrofitInstance3();
			SeguridadApi ejemploApi = retrofitInstance.create(SeguridadApi.class);

			Call<BodyDatosAfiliado> token = ejemploApi.datosAfiliado(headerRq, serviceID, serviceTransaction, userId,
					tipoDocumento, numeroDocumento);

			Response<BodyDatosAfiliado> execute = token.execute();

			BodyDatosAfiliado detalle = execute.body();

			if (detalle.getStatus().getStatusCode() != 200) {

				return "Error en servicio datosAfiliado";

			}

			return detalle.getAfiliado().getCelular().toString();

		} catch (Exception e) {

			return "Error de sistema";
		}

	}

	public static byte[] getSHA(String input) throws NoSuchAlgorithmException {
		// Static getInstance method is called with hashing SHA
		MessageDigest md = MessageDigest.getInstance("SHA-256");

		// digest() method called
		// to calculate message digest of an input
		// and return array of byte
		return md.digest(input.getBytes(StandardCharsets.UTF_8));
	}

	public static String toHexString(byte[] hash) {
		// Convert byte array into signum representation
		BigInteger number = new BigInteger(1, hash);

		// Convert message digest into hex value
		StringBuilder hexString = new StringBuilder(number.toString(16));

		// Pad with leading zeros
		while (hexString.length() < 32) {
			hexString.insert(0, '0');
		}

		return hexString.toString();
	}

	public static void safeClose(InputStream inputStream) {

		if (inputStream != null) {

			try {
				inputStream.close();
			} catch (IOException e) {

				e.printStackTrace();

			}
		}

	}

}
