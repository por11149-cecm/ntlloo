package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class Token {
  
  private String token;

}
