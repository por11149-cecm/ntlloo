package com.porvenir.appmovil.seguridad.utils;

public class ConstantesSeguridad {

    //Codigos de error
    public static final String NEG0007 = "NEG0007";
    public static final String NEG0004 = "NEG0004";
    public static final String NEG0009 = "NEG0009";
    public static final String NEG0029 = "NEG0029";
    public static final String TEC0006 = "TEC0006";
    public static final String TEC0008 = "TEC0008";
    public static final String TEC0009 = "TEC0009";
    public static final String NEG0021 = "NEG0021";
    public static final String NEG0024 = "NEG0024";
    public static final String NEG0030 = "NEG0030";
    public static final String NEG0032 = "NEG0032";
    
   
    

    //Descripcion error
    public static final String NEG0007_DESCRIPTION = "El caso no existe";
    public static final String NEG0009_DESCRIPTION = "No se ha cambiado información, no se guardará ningún cambio";
    public static final String TEC0006_DESCRIPCION = "Error interno del sistema";
    public static final String TEC0008_DESCRIPCION = "El servicio debe recibir solo los filtros idCaso";
    public static final String TEC0009_DESCRIPTION = "@Header serviceTransaction necesario";
    public static final String NEG0004_DESCRIPTION = "Los parametros de entrada son invalidos";
    public static final String NEG0021_DESCRIPTION = "El numero interno concursal no existe en concursal caso";
    public static final String NEG0024_DESCRIPTION = "El caso ya se encuentra registrado";
    public static final String NEG0029_DESCRIPTION = "No es posible realizar la exclusión";
    public static final String NEG0030_DESCRIPTION = "No hay planillas pendientes de acreditar que crucen con los afiliados en deuda para el caso";
    public static final String NEG0032_DESCRIPTION = "Problema";
    
    
    // constantes
    public static final String ACTIVO = "S";
    public static final String VALOR_NULL = "NULL";
    public static final String GESTION = "EN GESTION";
    public static final String OK = "OK";
    public static final String ALL = "ALL";
  	public static final String ID_AFILIADO = "casoRazAfilId";
  	public static final String AFILIADO_ID = "CASO_RAZ_AFIL_ID";
  	public static final String PARAMETRO_ORDEN = "DESC";
  	public static final String TIPO_IDEN_AFIL = "tipoIdentificacion";
  	public static final String NUM_IDENT_AFIL = "numeroIdentificacion";
  	public static final String PERIODO = "periodo";
  	public static final String AFILIADO = "afilId";
  	public static final String CASO = "casoId";
  	public static final String ESTADO_PERIODO = "EstadoPeriodo";
  	public static final String ORIGEN = "GOYA";	
  	public static final String EN_GESTION = "EN GESTION";
  	public static final String LISTA_PARA_ACREDITAR = "LISTA_PARA_ACREDITAR";
  	public static final String CARGADA = "CARGADA";
  	public static final String REVERSADA = "REVERSADA";
  	public static final String ANULADA = "ANULADA";
  	public static final String TP_EX_NO_GES = "TP_EX_NO_GES";
  	public static final String NIT_AF_PER = "NIT_AF_PER";
  	public static final String TIPO_ID_EMP = "TIPO_ID_EMP";
  	public static final String NUMERO_ID_EMP = "NUMERO_ID_EMP";
  	public static final String TIPO_ID_AFIL = "TIPO_ID_AFIL";
  	public static final String NUMERO_ID_AFIL = "NUMERO_ID_AFIL";
  	public static final String PERIODO_ADEUD = "PERIODO_ADEUD";
  	public static final String GESTOR_RESPON = "GESTOR_RESPON";
  	
}
