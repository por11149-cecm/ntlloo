package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class StatusTerminosYCondicionesResponse {
	
	private Integer statusCode;
	private String statusDesc;

}
