package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;


@Data
public class ReqContenido {

	private String tipoDocumento;
	private String producto;
	private String nombreReferencia;
	private String codigoReferencia;
	private String funcionalidad;
	private String tipoIdAfil;
	private String numeroIdAfil;
	
	
	
	
}


