package com.porvenir.appmovil.seguridad.errores;

import java.util.ArrayList;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class ErrorSalidaDTO {

    // ejemplo NEG200
    private String codigo;

    // El usuario no existe
    private String descripcion;

    // algo que quieran agregar
    private ArrayList<ErrorDetalleDTO> descripcionAdicional;

    public void agregarDescripcion(String detalleP) {

        ErrorDetalleDTO detalle = new ErrorDetalleDTO();
        detalle.setDetalle(detalleP);
        this.descripcionAdicional.add(detalle);

    }

}
