package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class ResponseValidationJWT {

	private Integer status;
	private String desc;
	private String logRef;
	private Long fechaUltimoAcceso;
	private String ipUltimoAcceso;
	
	
}
