package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;


@Data
public class EnrolamientoResponse {

  private Integer status;
  private String statusDesc;
  
}
