package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class HeaderRqJWT {

		private String rqUID;
		private String channelID;
		private String clientID;
		private String clientName;
		private String sucursalID;
		private String sucursalName;
		private String ipAddr;
		private String sessKey;
		private String clientDt;
		private String userID;
		private String loginID;
		private String revCode;
		private String revUID;
		private String revAuthID;
	
	
}
