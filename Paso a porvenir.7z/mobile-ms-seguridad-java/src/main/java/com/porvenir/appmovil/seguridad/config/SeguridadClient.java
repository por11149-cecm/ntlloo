package com.porvenir.appmovil.seguridad.config;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

@Configuration
public class SeguridadClient {
	
	private static Retrofit retrofit;

	@Value("${application.mobile.baseUrlMicrosoft}")
	private String baseUrlMicrosoft;

	private static String BASE_URL_MICROSOFT;

	@Value("${application.mobile.baseUrlMicrosoft}")
	public void setNameStatic(String baseUrlMicrosoft){
        SeguridadClient.BASE_URL_MICROSOFT = baseUrlMicrosoft;
	}
	
	
	private static Retrofit retrofit2;
	
	@Value("${application.mobile.baseUrlAutenticacion}")
	private String baseUrlAutenticacion;

	private static String BASE_URL_AUTENTICACION;

	@Value("${application.mobile.baseUrlAutenticacion}")
	public void setNameStatic2(String baseUrlAutenticacion){
        SeguridadClient.BASE_URL_AUTENTICACION = baseUrlAutenticacion;
	}
	
	
	
	private static Retrofit retrofit3;
	
	@Value("${application.mobile.baseUrl}")
	private String baseUrl;

	private static String BASE_URL;

	@Value("${application.mobile.baseUrl}")
	public void setNameStatic3(String baseUrl){
        SeguridadClient.BASE_URL = baseUrl;
	}
	
	

	@Bean
	public static Retrofit retrofitInstance() throws KeyManagementException, NoSuchAlgorithmException {

	
		
		if (retrofit == null) {
			retrofit = new retrofit2.Retrofit.Builder().baseUrl(BASE_URL_MICROSOFT)
					.addConverterFactory(GsonConverterFactory.create())
					.addCallAdapterFactory(RxJava2CallAdapterFactory.create()).build();

		}
		return retrofit;

	}

	@Bean
	public static Retrofit retrofitInstance2() throws KeyManagementException, NoSuchAlgorithmException {

				
	
		
		if (retrofit2 == null) {
			retrofit2 = new retrofit2.Retrofit.Builder().baseUrl(BASE_URL_AUTENTICACION)
					.addConverterFactory(GsonConverterFactory.create())
					.addCallAdapterFactory(RxJava2CallAdapterFactory.create()).client(getUnsafeOkHttpClient()).build();

		}
		return retrofit2;

	}
	
	@Bean
	public static Retrofit retrofitInstance3() throws KeyManagementException, NoSuchAlgorithmException {

	
		
		if (retrofit3 == null) {
			retrofit3 = new retrofit2.Retrofit.Builder().baseUrl(BASE_URL)
					.addConverterFactory(GsonConverterFactory.create())
					.addCallAdapterFactory(RxJava2CallAdapterFactory.create()).client(getUnsafeOkHttpClient()).build();

		}
		return retrofit3;

	}
	
	private static OkHttpClient getUnsafeOkHttpClient() throws NoSuchAlgorithmException, KeyManagementException {

		X509TrustManager x509TrustManager = new X509TrustManager() {
			@Override
			public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
			}

			@Override
			public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
			}

			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return new java.security.cert.X509Certificate[] {};
			}
		};

		final SSLContext sslContext = SSLContext.getInstance("SSL");
		final TrustManager[] trustAllCerts = new TrustManager[] { x509TrustManager };

		sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

		
		
		OkHttpClient.Builder client = new OkHttpClient.Builder();

		client.writeTimeout(60, TimeUnit.SECONDS);
		client.readTimeout(60, TimeUnit.SECONDS);
		client.connectTimeout(60, TimeUnit.SECONDS);
		client.callTimeout(60, TimeUnit.SECONDS);
		
		client.sslSocketFactory(sslContext.getSocketFactory(), x509TrustManager);
		client.hostnameVerifier((hostname, session) -> true);
		OkHttpClient client2 = client.build();
		return client2;

	}




}
