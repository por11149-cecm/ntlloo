package com.porvenir.bff.datosAfiliadoWeb.errores;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorDetalleDTO {

	private String detalle;
		
}

