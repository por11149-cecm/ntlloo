package com.porvenir.bff.datosAfiliadoWeb.model;

import lombok.Data;

@Data
public class NewContent {
	
    public String barrio;
    public String requiredAttribute1;
    public String requiredAttribute2;
    public String ciudadIdDescripcion;
    public String departamentoIdDescripcion;
    public String deptoCiudad;
    public String direccion;
    public String numeroIdentificacion;
    public String edad;
    public String correoElectronico;
    public String envioEmail;
    public String envioSMS;
    public String fechaNacimiento;
    public String fechaProxActualiza;
    public String fechaUltActualiza;
    public String genero;
    public String generoDescripcion;
    public String idCelular;
    public String idDireccion;
    public String idEMail;
    public String idTelefonoFijo;
    public String lugarExp;
    public String nombre;
    public String pais;
    public String primerApellido;
    public String primerNombre;
    public String segundaCiudad;
    public String segundaDireccion;
    public String segundaIdDireccion;
    public String segundoApellido;
    public String segundoBarrio;
    public String segundoEmail;
    public String segundoIdEMail;
    public String segundoNombre;
    public Long telefonoFijo;
    public String tipoEnvioFisico;
    public String tipoIdentificacionDescripcion;
    public String tipoMensajeEmail;

    public ContactoTO contactoTO;

}
