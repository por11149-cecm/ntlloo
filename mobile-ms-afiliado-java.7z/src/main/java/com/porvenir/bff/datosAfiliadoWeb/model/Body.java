package com.porvenir.bff.datosAfiliadoWeb.model;

import lombok.Data;

@Data
public class Body {
	
	public Status status;
	public Content afiliado;

}
