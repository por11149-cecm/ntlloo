package com.porvenir.bff.datosAfiliadoWeb.config;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

@Configuration
public class AfiliadoClient {

	@Value("${application.bus.baseUrl}")
	private String baseUrl;

	private static String BASE_URL;

	@Value("${application.bus.baseUrl}")
	public void setNameStatic(String baseUrl){
        AfiliadoClient.BASE_URL = baseUrl;
    }

	
	
	@Bean
	public static Retrofit retrofitInstance() throws KeyManagementException, NoSuchAlgorithmException {

		return new retrofit2.Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create())
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create()).client(getUnsafeOkHttpClient()).build();

	}

	private static OkHttpClient getUnsafeOkHttpClient() throws NoSuchAlgorithmException, KeyManagementException {

		X509TrustManager x509TrustManager = new X509TrustManager() {
			@Override
			public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
			}

			@Override
			public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
			}

			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return new java.security.cert.X509Certificate[] {};
			}
		};

		final SSLContext sslContext = SSLContext.getInstance("SSL");
		final TrustManager[] trustAllCerts = new TrustManager[] { x509TrustManager };

		sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

		OkHttpClient.Builder client = new OkHttpClient.Builder();
		client.sslSocketFactory(sslContext.getSocketFactory(), x509TrustManager);
		client.hostnameVerifier((hostname, session) -> true);
		OkHttpClient client2 = client.build();
		return client2;

	}
}
