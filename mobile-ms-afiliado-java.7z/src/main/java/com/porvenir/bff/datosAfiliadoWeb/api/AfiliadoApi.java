package com.porvenir.bff.datosAfiliadoWeb.api;


import com.porvenir.bff.datosAfiliadoWeb.model.Body;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Query;

public interface AfiliadoApi {
	
	@GET("/wsConsultarDatosAfiliadoWeb/AAF02S01V01/v1/ConsultarDatosAfiliado")
	public Call<Body> datosAfiliado(
			@Header("headerRq") String headerRq,
			@Header("serviceID") String serviceID,
			@Header("serviceTransaction") String serviceTransaction,
			@Header("userId") String userId,
			@Query("tipoDocumento") String tipoDocumento,
			@Query("numeroDocumento")String numeroDocumento);

}
