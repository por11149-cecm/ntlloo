package com.porvenir.bff.datosAfiliadoWeb.services;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.http.ResponseEntity;


import com.porvenir.bff.datosAfiliadoWeb.model.RequestContent;



public interface AfiliadoService {

	public ResponseEntity<Object> datosAfiliado(String headerRq, String serviceID, String serviceTransaction, String userId, String tipoIdentificacion, String numeroIdentificacion, String fecha) throws IOException, KeyManagementException, NoSuchAlgorithmException;
}
