package com.porvenir.bff.datosAfiliadoWeb.model;

import lombok.Data;

@Data
public class ContactoTO {

	public String nombreCompleto;
	
}
