package com.porvenir.bff.datosAfiliadoWeb.service.impl;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.porvenir.bff.datosAfiliadoWeb.api.AfiliadoApi;
import com.porvenir.bff.datosAfiliadoWeb.config.AfiliadoClient;
import com.porvenir.bff.datosAfiliadoWeb.errores.ExceptionDeSistema;
import com.porvenir.bff.datosAfiliadoWeb.model.Body;
import com.porvenir.bff.datosAfiliadoWeb.model.ContactoTO;
import com.porvenir.bff.datosAfiliadoWeb.model.NewBody;
import com.porvenir.bff.datosAfiliadoWeb.model.NewContent;
import com.porvenir.bff.datosAfiliadoWeb.model.Status;
import com.porvenir.bff.datosAfiliadoWeb.services.AfiliadoService;
import com.porvenir.bff.datosAfiliadoWeb.utils.ConstantesAfiliado;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;

@Service
public class AfiliadoServiceImpl implements AfiliadoService {
	
	
	@Override
	public ResponseEntity<Object> datosAfiliado(String headerRq, String serviceID, String serviceTransaction,
			String userId, String tipoIdentificacion, String numeroIdentificacion, String fecha)
			throws IOException, KeyManagementException, NoSuchAlgorithmException {
		
		
		
		String tipoId = "CC";
		String generoDescripcion = "";
		String requiredAttribute1 = "";
		String requiredAttribute2 = "";
		Retrofit retrofitInstance = AfiliadoClient.retrofitInstance();
		AfiliadoApi afiliadoApi = retrofitInstance.create(AfiliadoApi.class);
		
		
		switch(tipoIdentificacion) {
		
			case "1":
				
				tipoId = "NIT";
				break;
			case "2":
				
				tipoId = "CC";
				break;
			case "3":
				
				tipoId = "CE";
				break;
			case "4":
				
				tipoId = "TI";
				break;
			case "7":
				
				tipoId = "RC";
				break;
			case "9":
				
				tipoId = "NUIP";
				break;
		
		
		}
		
		try {
			if (tipoIdentificacion.isEmpty() || numeroIdentificacion.isEmpty()) {
				return ResponseEntity.badRequest()
						.body(ExceptionDeSistema.builder().codigo(ConstantesAfiliado.NEG0004)
								.descripcion(ConstantesAfiliado.NEG0004_DESCRIPTION).httpStatus(HttpStatus.BAD_REQUEST)
								.build());
			}
			
					
					
			
			Call<Body> datosAfiliado = afiliadoApi.datosAfiliado(headerRq, serviceID, serviceTransaction, userId, tipoId, numeroIdentificacion);
			Response<Body> execute = datosAfiliado.execute();
			Body datosBasicosAfiliado = execute.body();

			if (datosBasicosAfiliado.getStatus().getStatusCode() != 200) {

				return ResponseEntity.badRequest()
						.body(ExceptionDeSistema.builder().codigo(ConstantesAfiliado.NEG0032)
								.descripcion(ConstantesAfiliado.NEG0032_DESCRIPTION + " "
										+ datosBasicosAfiliado.getStatus().getStatusDesc())
								.httpStatus(HttpStatus.BAD_REQUEST).build());

			}
			
			if(datosBasicosAfiliado.getAfiliado().getGenero().equalsIgnoreCase("M")) {
				
				generoDescripcion = "Masculino";
			
			}else if (datosBasicosAfiliado.getAfiliado().getGenero().equalsIgnoreCase("F")) {
				
				generoDescripcion = "Femenino";
				
			}else {
				
				generoDescripcion = "";
				
				
			}
			
			
			if (datosBasicosAfiliado.getAfiliado().getCelular() != null) {
				
				String celularString = datosBasicosAfiliado.getAfiliado().getCelular().toString();
				String[] celularSeparado = celularString.split(""); 
				
				
				requiredAttribute1 = celularSeparado[0]+celularSeparado[1]+celularSeparado[2];
				requiredAttribute2 = celularSeparado[7]+celularSeparado[8]+celularSeparado[9];
				
			}else {
				
				requiredAttribute1 = "";
				requiredAttribute2 = "";
				
			}

			
			NewContent newContent = new NewContent();
			
			newContent.setBarrio(datosBasicosAfiliado.getAfiliado().getBarrio());
			
			newContent.setRequiredAttribute1(requiredAttribute1);
			newContent.setRequiredAttribute2(requiredAttribute2);
			
			newContent.setCiudadIdDescripcion(datosBasicosAfiliado.getAfiliado().getCiudad());
			newContent.setDepartamentoIdDescripcion(datosBasicosAfiliado.getAfiliado().getDepartamento());
			newContent.setDeptoCiudad(datosBasicosAfiliado.getAfiliado().getDeptoCiudad());
			newContent.setDireccion(datosBasicosAfiliado.getAfiliado().getDireccion());
			newContent.setNumeroIdentificacion(datosBasicosAfiliado.getAfiliado().getDocumento());
			newContent.setEdad(datosBasicosAfiliado.getAfiliado().getEdad());
			newContent.setCorreoElectronico(datosBasicosAfiliado.getAfiliado().getEmail());
			newContent.setEnvioEmail(datosBasicosAfiliado.getAfiliado().getEnvioEmail());
			newContent.setEnvioSMS(datosBasicosAfiliado.getAfiliado().getEnvioSMS());
			newContent.setFechaNacimiento(datosBasicosAfiliado.getAfiliado().getFechaNac());
			newContent.setFechaProxActualiza(datosBasicosAfiliado.getAfiliado().getFechaProxActualiza());
			newContent.setFechaUltActualiza(datosBasicosAfiliado.getAfiliado().getFechaUltActualiza());
			newContent.setGenero(datosBasicosAfiliado.getAfiliado().getGenero());
			newContent.setGeneroDescripcion(generoDescripcion);
			newContent.setIdCelular(datosBasicosAfiliado.getAfiliado().getIdCelular());
			newContent.setIdDireccion(datosBasicosAfiliado.getAfiliado().getIdDireccion());
			newContent.setIdEMail(datosBasicosAfiliado.getAfiliado().getIdEMail());
			newContent.setIdTelefonoFijo(datosBasicosAfiliado.getAfiliado().getIdTelefonoFijo());
			newContent.setLugarExp(datosBasicosAfiliado.getAfiliado().getLugarExp());
			newContent.setNombre(datosBasicosAfiliado.getAfiliado().getNombre());
			newContent.setPais(datosBasicosAfiliado.getAfiliado().getPais());
			newContent.setPrimerApellido(datosBasicosAfiliado.getAfiliado().getPrimerApellido());
			newContent.setPrimerNombre(datosBasicosAfiliado.getAfiliado().getPrimerNombre());
			newContent.setSegundaCiudad(datosBasicosAfiliado.getAfiliado().getSegundaCiudad());
			newContent.setSegundaDireccion(datosBasicosAfiliado.getAfiliado().getSegundaDireccion());
			newContent.setSegundaIdDireccion(datosBasicosAfiliado.getAfiliado().getSegundaIdDireccion());
			newContent.setSegundoApellido(datosBasicosAfiliado.getAfiliado().getSegundoApellido());
			newContent.setSegundoBarrio(datosBasicosAfiliado.getAfiliado().getSegundoBarrio());
			newContent.setSegundoEmail(datosBasicosAfiliado.getAfiliado().getSegundoEmail());
			newContent.setSegundoIdEMail(datosBasicosAfiliado.getAfiliado().getSegundoIdEMail());
			newContent.setSegundoNombre(datosBasicosAfiliado.getAfiliado().getSegundoNombre());
			
			newContent.setTelefonoFijo(datosBasicosAfiliado.getAfiliado().getTelefonoFijo());
			newContent.setTipoEnvioFisico(datosBasicosAfiliado.getAfiliado().getTipoEnvioFisico());
			newContent.setTipoIdentificacionDescripcion(datosBasicosAfiliado.getAfiliado().getTipoIdentificacion());
			newContent.setTipoMensajeEmail(datosBasicosAfiliado.getAfiliado().getTipoMensajeEmail());
			
			ContactoTO contactoTO = new ContactoTO();
			contactoTO.setNombreCompleto(datosBasicosAfiliado.getAfiliado().getNombre());
			
			newContent.setContactoTO(contactoTO);
			
			Status status = new Status();
			status.setStatusCode(0);
			status.setStatusDesc("OK");
			
			NewBody newBody = new NewBody();
			newBody.setContent(newContent);
			newBody.setStatus(status);
			
			
			return ResponseEntity.ok().body(newBody);
			
			
		}catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesAfiliado.TEC0006)
							.descripcion(ConstantesAfiliado.TEC0006_DESCRIPCION).agregarDescripcion2("Error: " + e)
							.build());

		}
	}



}
