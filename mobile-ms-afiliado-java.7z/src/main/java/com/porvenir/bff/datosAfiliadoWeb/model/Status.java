
package com.porvenir.bff.datosAfiliadoWeb.model;


import lombok.Data;

@Data
public class Status {

    public Integer statusCode;
    public String statusDesc;

}
