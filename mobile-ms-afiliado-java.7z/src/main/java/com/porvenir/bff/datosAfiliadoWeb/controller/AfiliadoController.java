package com.porvenir.bff.datosAfiliadoWeb.controller;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.porvenir.bff.datosAfiliadoWeb.model.RequestContent;
import com.porvenir.bff.datosAfiliadoWeb.services.AfiliadoService;

import io.swagger.annotations.Api;

@RequestMapping("${application.mobile.api.path}")
@RestController
@Api(value = "Microservicio BFF datosAfiliado")
public class AfiliadoController {

	@Autowired
	AfiliadoService afiliadoService;
	@Value("${application.bus.headerRqDatosAfiliado}")
	private String headerRqDatosAfiliado;
	@Value("${application.bus.serviceIDDatosAfiliado}")
	private String serviceIDDatosAfiliado;

	@Value("${application.bus.serviceTransactionDatosAfiliado}")
	private String serviceTransactionDatosAfiliado;

	@Value("${application.bus.userIdDatosAfiliado}")
	private String userIdDatosAfiliado;

	/**
	 * Metodo encargado de responder informacion basica del afiliado.
	 * 
	 * @param tipoIdentificacion   Establece el tipo de identificacion del afiliado
	 *                             a consultar.
	 * @param numeroIdentificacion Establece el tipo de identificacion del afiliado
	 *                             a consultar.
	 * @return Responde con la estructura de datos basicos del afiliado.
	 * @throws IOException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	@PostMapping(path = "/datosAfiliado")
	public ResponseEntity<Object> datosAfiliado(@RequestHeader(value = "canal", required = true) String canal,
			@RequestHeader(value = "ipaddr", required = false) String ipaddr,
			@RequestHeader(value = "idrequest", required = true) String idrequest,
			@RequestHeader(value = "idusuario", required = true) String idusuario,
			@RequestHeader(value = "fecha", required = true) String fecha,
			@RequestHeader(value = "authorization", required = true) String authorization,
			@RequestParam(value = "tipoIdentificacion") String tipoIdentificacion,
			@RequestParam(value = "numeroIdentificacion") String numeroIdentificacion)
			throws IOException, KeyManagementException, NoSuchAlgorithmException {
		
		return afiliadoService.datosAfiliado(headerRqDatosAfiliado, serviceIDDatosAfiliado,
				serviceTransactionDatosAfiliado, userIdDatosAfiliado, tipoIdentificacion, numeroIdentificacion, fecha);

	}

}
