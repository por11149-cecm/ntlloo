package com.porvenir.bff.datosAfiliadoWeb.model;

import lombok.Data;

@Data
public class RequestContent {

	private String tipoIdentificacion;
	private String numeroIdentificacion;
	
}
