package com.porvenir.bff.datosAfiliadoWeb.model;

import lombok.Data;

@Data
public class NewBody {

	public Status status;
	public NewContent content;

}
