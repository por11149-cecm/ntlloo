package com.porvenir.bff.datosAfiliadoWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatosAfiliadoWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatosAfiliadoWebApplication.class, args);
	}

}
